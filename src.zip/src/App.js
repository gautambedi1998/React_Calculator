import { useReducer } from 'react';
import './style.css';


const reducer = (state,action) =>{
  switch(action.type){
    case 'INCREMENT':
      break;
  }
}

function App() {
  const[{previous},{current},{operation},dispatch] = useReducer(reducer,{result: 0})
  return (
    <div className='calculator'>
      <div className='output'>
        <div className='previous_operation'> {previous} {operation}</div>
        <div className='current_operation'>{current}</div>
      </div>
      <button className='span_2'>AC</button>
      <button>DEL</button>
      <button>÷</button>
      <button>1</button>
      <button>2</button>
      <button>3</button>
      <button>*</button>
      <button>4</button>
      <button>5</button>
      <button>6</button>
      <button>+</button>
      <button>7</button>
      <button>8</button>
      <button>9</button>
      <button>-</button>
      <button>.</button>
      <button>0</button>
      <button  className='span_2'>=</button>
    </div>
  );
}

export default App;
